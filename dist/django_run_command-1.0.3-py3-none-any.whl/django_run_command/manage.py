# from django_run_command.api import start_thread_task
#
# @staticmethod
# def run_command(command, arg):
#     if arg:
#         start_thread_task(command, arg)
#     else:
#         start_thread_task(command)
#
