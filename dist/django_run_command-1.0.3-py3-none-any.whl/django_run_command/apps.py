from django.apps import AppConfig


class DjangoRunCommandConfig(AppConfig):
    name = 'django_run_command'
